<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<!--
Name: Austin Roy-Stewart
Date: 05/01/2022
IT 207, Lab 4.
!-->
	<head>
		<meta charset="UTF-8">
		<title> SQL Display Comments </title>
		<link rel="stylesheet" href="../CSS/home_style.css" type="text/css"/>
	</head>
	<body>
    <div id= "container">
        <div id="nav">
            <p>
            <?php
                include '../SSI/menu.inc';
            ?>
            </p>
        </div>
		<div id="non-nav_box">
		<div id="header">
        <div id="course_info">
            <h1><b>IT-207_006 Spring 2020</b><br/></h1>
                <p>Professor Taheri<br/>
                George Mason University</p>
        </div>
        <div id="personal_info">
            <h2><b>Austin Roy-Stewart</b><br/></h2>
            <p><a href="mailto: aroystew@gmu.edu">aroystew@gmu.edu</a><br/>
            <?php echo "Last modified: " . date ("F d Y H:i:s.", getlastmod()); ?>
        </div>
        </div>
        <div id = "content">
            <p>
			<?php
                $sortvalue = "x";
                echo '<h1>Random Post</h1><br />Breaking news! Colossal Dreadmaws are running rampant through New York City. Humanity is lost...<br /><br />';
                echo '<h1>Comments</h1><hr />';
                if(isset($_POST['sorta'])){
                    $connection = mysqli_connect("helios.vse.gmu.edu", "aroystew", "jocheeth", "aroystew") or die("connection is not successful ERROR:". mysqli_connect_error());
                    $result = mysqli_query($connection, "SELECT Name, Email, Comment FROM commenting_user ORDER BY Name ASC");
                    $row = mysqli_fetch_row($result);
                    $commentCounter = 1;
                    do{
                        echo $commentCounter . '.<br />Name: <a href="mailto:' . $row[1] . '">' . $row[0] . '</a><br />Comment: ' . $row[2] . '<hr />';
                        $commentCounter++;
                        $row = mysqli_fetch_row($result);
                    }while($row);
                    mysqli_close($connection);
                    $sortvalue = "a";
                }
                else if(isset($_POST['sortd'])){
                    $connection = mysqli_connect("helios.vse.gmu.edu", "aroystew", "jocheeth", "aroystew") or die("connection is not successful ERROR:". mysqli_connect_error());
                    $result = mysqli_query($connection, "SELECT Name, Email, Comment FROM commenting_user ORDER BY Name DESC");
                    $row = mysqli_fetch_row($result);
                    $commentCounter = 1;
                    do{
                        echo $commentCounter . '.<br />Name: <a href="mailto:' . $row[1] . '">' . $row[0] . '</a><br />Comment: ' . $row[2] . '<hr />';
                        $commentCounter++;
                        $row = mysqli_fetch_row($result);
                    }while($row);
                    mysqli_close($connection);
                    $sortvalue = "d";
                }
                else{
                    $connection = mysqli_connect("helios.vse.gmu.edu", "aroystew", "jocheeth", "aroystew") or die("connection is not successful ERROR:". mysqli_connect_error());
                    $result = mysqli_query($connection, "SELECT Name, Email, Comment FROM commenting_user");
                    $row = mysqli_fetch_row($result);
                    $commentCounter = 1;
                    do{
                        echo $commentCounter . '.<br />Name: <a href="mailto:' . $row[1] . '">' . $row[0] . '</a><br />Comment: ' . $row[2] . '<hr />';
                        $commentCounter++;
                        $row = mysqli_fetch_row($result);
                    }while($row);
                    mysqli_close($connection);
                }
                echo '<a href="SQLindex.php">Add New Comment</a><br />';
            ?>
            <form action = "SQLcomments.php" method="post">
            <input type="submit" name="sorta" value="Sort Comments A-Z (by name)"></input>
            </form>
            <form action = "SQLcomments.php" method="post">
            <input type="submit" name="sortd" value="Sort Comments Z-A (by name)"></input>
            </form>
            <form action = "SQLcomments.php" method="post">
            Delete Comment Number: <input type = "text" name="deleteNum"></input>
            <input type="submit" name="submit" value="Delete"></input>
            </form>
            <?php
            //all in one form for convenience
                if(isset($_POST['submit'])){
                    $deleteNum = $_POST['deleteNum'];
                    $connection = mysqli_connect("helios.vse.gmu.edu", "aroystew", "jocheeth", "aroystew") or die("connection is not successful ERROR:". mysqli_connect_error());
                    //fetch row as before to find contents
                    //check if the sorts where pressed and delete accordingly
                    if(strcmp($sortvalue, "a") == 0){
                        $result = mysqli_query($connection, "SELECT Name, Email, Comment FROM commenting_user ORDER BY Name ASC");
                    }
                    else if(strcmp($sortvalue, "d") == 0){
                        $result = mysqli_query($connection, "SELECT Name, Email, Comment FROM commenting_user ORDER BY Name DESC");
                    }
                    else{
                        $result = mysqli_query($connection, "SELECT Name, Email, Comment FROM commenting_user");
                    }
                    $row = mysqli_fetch_row($result);
                    $currentRow = 1;
                    do{
                        if($currentRow == $deleteNum){
                            mysqli_query($connection, "DELETE FROM commenting_user WHERE Name='$row[0]' AND Email='$row[1]' AND Comment='$row[2]'");
                            break;
                        }
                        $row = mysqli_fetch_row($result);
                        $currentRow++;
                    }while($row);
                }
            ?>
            </p>
        </div>
		</div>
        <div id="footer">
            <p>
            <?php
            echo("<em>This website complies with the Mason Honor Code and 
            current Copyright Laws in regards to academic work.</em>")
            ?>
            </p>
        </div>
    </div>
    </body>
</html>