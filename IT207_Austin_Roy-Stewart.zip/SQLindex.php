<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<!--
Name: Austin Roy-Stewart
Date: 05/01/2022
IT 207, Lab 4.
!-->
	<head>
		<meta charset="UTF-8">
		<title> SQL Assignment 4 </title>
		<link rel="stylesheet" href="../CSS/home_style.css" type="text/css"/>
	</head>
	<body>
	<div id= "container">
        <div id="nav">
            <p>
            <?php
                include '../SSI/menu.inc';
            ?>
            </p>
        </div>
		<div id="non-nav_box">
		<div id="header">
        <div id="course_info">
            <h1><b>IT-207_006 Spring 2020</b><br/></h1>
                <p>Professor Taheri<br/>
                George Mason University</p>
        </div>
        <div id="personal_info">
            <h2><b>Austin Roy-Stewart</b><br/></h2>
            <p><a href="mailto: aroystew@gmu.edu">aroystew@gmu.edu</a><br/>
            <?php echo "Last modified: " . date ("F d Y H:i:s.", getlastmod()); ?>
        </div>
        </div>
        <div id = "content">
			<p>
			<?php
				echo '<h1>Random Post</h1><br />Breaking news! Colossal Dreadmaws are running rampant through New York City. Humanity is lost...';
			?>
            <form action="SQLadd.php" method="post">
                <h1>Add Comment</h1><hr />
                Name: <input type="text" name="name"></input><br />
                Email: <input type="email" name="email"></input><br />
                Comments: <input type="text" name="comment"></input><br />
                <input type="submit" name="submit" value="Sign"></input>
                <input type="reset" name="reset" value="reset"></input>
            </form>
            <hr />
            <?php
                echo '<a href="SQLcomments.php">View Posting Comments</a>';
            ?>
			</p>
        </div>
		</div>
        <div id="footer">
            <p>
            <?php
            echo("<em>This website complies with the Mason Honor Code and 
            current Copyright Laws in regards to academic work.</em>")
            ?>
            </p>
        </div>
    </div>
	</body>
</html>