<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<!--
Name: Austin Roy-Stewart
Date: 05/01/2022
IT 207, Lab 4.
!-->
	<head>
		<meta charset="UTF-8">
		<title> SQL Add Comment </title>
		<link rel="stylesheet" href="../CSS/home_style.css" type="text/css"/>
	</head>
	<body>
    <div id= "container">
        <div id="nav">
            <p>
            <?php
                include '../SSI/menu.inc';
            ?>
            </p>
        </div>
		<div id="non-nav_box">
		<div id="header">
        <div id="course_info">
            <h1><b>IT-207_006 Spring 2020</b><br/></h1>
                <p>Professor Taheri<br/>
                George Mason University</p>
        </div>
        <div id="personal_info">
            <h2><b>Austin Roy-Stewart</b><br/></h2>
            <p><a href="mailto: aroystew@gmu.edu">aroystew@gmu.edu</a><br/>
            <?php echo "Last modified: " . date ("F d Y H:i:s.", getlastmod()); ?>
        </div>
        </div>
        <div id = "content">
            <p>
			<?php
                //Validation
                if(isset($_POST['submit'])){
                    $email = $_POST['email'];
                    $name = $_POST['name'];
                    $comment = $_POST['comment'];
                    //people can have the same name but not the same email so we will not use name
                    //to confirm if someone has posted, instead using email.
                    $connection = mysqli_connect("helios.vse.gmu.edu", "aroystew", "jocheeth", "aroystew") or die("connection is not successful ERROR:". mysqli_connect_error());
                    //iterate through each row and check the email of the user
                    $result = mysqli_query($connection, "SELECT Email FROM commenting_user");
                    $row = mysqli_fetch_row($result);
                    $validator = 1;
                    do{
                        if($row[0] == $email){
                           $validator = 0;
                        }
                        $row = mysqli_fetch_row($result);
                    }while($row);
                    
                    if($validator == 0){
                        echo "<h1>Comment Not Added</h1><hr />You cannot post twice!";
                    }
                    else{
                        echo '<h1>Comments Added</h1><hr />';
                        echo 'Name: '. $name;
                        echo '<br />Comments: '. $comment;
                        mysqli_query($connection, "INSERT INTO commenting_user (Name, Email, Comment) VALUES ('$name', '$email', '$comment')");
                    }
                    mysqli_close($connection);
                }
                echo '<a href="SQLindex.php">Someone Else Want to Comment?</a><br />';
                echo '<a href="SQLcomments.php">View Posting Comments</a>';
            ?>
            </p>
        </div>
		</div>
        <div id="footer">
            <p>
            <?php
            echo("<em>This website complies with the Mason Honor Code and 
            current Copyright Laws in regards to academic work.</em>")
            ?>
            </p>
        </div>
    </div>
    </body>
</html>